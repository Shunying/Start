#include "../include/arbitrarystate.h"

ArbitraryState::ArbitraryState(double x, double y, double z, double rho) : State(x, y, z, rho) {

}

int ArbitraryState::transit() {
    // do some random stuff here
}
